/***************************************************************************

								mag.h

Company: USC/ISI
License: Proprietary
Author(s): Will Bezouska

Purpose: Provide hardware interface to magnetometer.

Usage: See the descriptions of each function below.

Changelog:

Date 	 |  Au.  |	Notes
07-13-10  Will	Initial revision.		

****************************************************************************
*/

#ifndef __MAG_H__
#define __MAG_H__

//========================================
//  			Dependencies
//========================================
#include "common.h"
#include "spi.h"						// SPI functionality					



//========================================
// 			Data Structure
//========================================
typedef struct {
	signed int counts[3];
	float microTesla[3];
} mag_s;


//========================================
// 			Driver Functions
//========================================

ReturnErr_t mag_init();								// Initialize Magnetometer SPI pins
ReturnErr_t readAllMagAxis(signed int * reading, short reset);	// Read all three axis for magnetometer
ReturnErr_t convertFrameMagToBody(signed int * readings, mag_s * Data);		// Mag frame and unit conversion
ReturnErr_t mag_functional_check(unsigned int max_time_seconds);


//========================================
// 		Development Functions
//========================================

#ifdef DEBUG
void printMagData(signed int * reading);
void magAutomaticDataCollection(long iterations, short continuous, short human);
#endif // DEBUG

#endif // __MAG_H__