/*

			address.h

Header file to store useful addresses.
It's a good idea to check for consistency between the 
addresses and the size allocations. 

See the associated Address_Helper.xls file.

*/

#ifndef __ADDRESSES__
#define __ADDRESSES__

	#ifdef UPPER_PPM
		#include "address_upper.h"
	#else
		#include "address_lower.h"
	#endif


#endif