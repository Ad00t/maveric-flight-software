#include "ina226.h"

#module					// !!! Important: This command makes everything below scoped only to this file.

int16 ina226_read_16(unsigned int8 add, unsigned int8 reg)
{
	//I2C INA226 reading routine
	//int8(i2c address), int8(i2c register), char(2 bytes read register pointer)  -> none
	//reads the bytes present in the i2c register of the addressed device and saves it on read_data 
	//example: ina226_write_16(INA226_ADDRESS_12, INA226_REG_CALIBRATION, calibration_setting)
	// unsigned char ina226_rdata[2]; // 2-byte ina226 reading
	
	unsigned int8 addw, addr;
	unsigned int16 read_data;

	addw = add<<1;
	addr = addw | 0x01;
		
	i2c_start(I2C_1);
	i2c_write(I2C_1, addw);
	i2c_write(I2C_1, reg);
	i2c_start(I2C_1);
	i2c_write(I2C_1, addr);

	read_data = i2c_read(I2C_1);
	read_data = (read_data<<8);
	read_data = read_data | i2c_read(I2C_1);
	i2c_stop(I2C_1);

	return read_data;		
}

void ina226_write_16(unsigned int8 add, unsigned int8 reg, unsigned int16 write_data)
{
	//I2C INA226 writing routine
	//int8(i2c address), int8(i2c register), char(2 bytes write register pointer)  -> bool
	//Writes the bytes present in write_data into the i2c register of the addressed device 
	//example: ina226_write_16(INA226_ADDRESS_12, INA226_REG_CALIBRATION, calibration_setting)
	// unsigned char ina226_wdata[2]; // 2-byte ina226 writing

	unsigned int8 addw, addr, msb, lsb;

	addw = add<<1;
	addr = addw | 0x01;

	lsb = write_data;
	msb = write_data>>8;
	
	i2c_start(I2C_1);
	i2c_write(I2C_1, addw);
	i2c_write(I2C_1, reg);
	i2c_write(I2C_1, msb);
	i2c_write(I2C_1, lsb);
	i2c_stop(I2C_1);	
}

int1 ina226_init(unsigned int8 add)
{
	//int8(i2c address) -> bool
	//Check if the ina226 device is connected in the indicated address (add)
	//example: ina226_init(INA226_ADDRESS_12) returns TRUE if there is a INA226 connected in that direction, otherwise return FALSE
	unsigned int16 rdata;
			
	rdata = ina226_read_16(add, INA226_REG_MANID);

	if (rdata ==0x5449)
	{
		rdata = ina226_read_16(add, INA226_REG_ID);
		if (rdata==0x2260)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	} 
	else
	{
		return 0;
	}	
}

void ina226_configure(unsigned int8 add, 
					  unsigned int16 average=INA226_MODE_1,
					  unsigned int16 vbusct = INA226_MODE_5,  
					  unsigned int16 vshct = INA226_MODE_5, 
					  unsigned int16 setmode = INA226_MODE_8)
{
	unsigned int16 ina226_config;
	// Default values for the configuration register
	ina226_config = 0x4127;

	if ((average <= INA226_MODE_8) && (average >= INA226_MODE_1))
	{
		ina226_config = average<<9 | ina226_config;
	}

	if ((vbusct <= INA226_MODE_8) && (vbusct >= INA226_MODE_1))
	{
		ina226_config = vbusct<<6 | ina226_config;
	}

	if ((vshct <= INA226_MODE_8) && (vshct >= INA226_MODE_1))
	{
		ina226_config = vshct<<3 | ina226_config;
	}

	if ((setmode <= INA226_MODE_8) && (setmode >= INA226_MODE_1))
	{
		ina226_config = setmode<<3 | ina226_config;
	}
	ina226_write_16(add, INA226_REG_CONFIG, ina226_config);
}

void ina226_calibrate(unsigned int8 add, unsigned int16 calibration = 0x1400)
{
 // For R_shunt = 1 mohm and 1 mA/bit resolution calibration = 0x1400
 	ina226_write_16(add, INA226_REG_CALIBRATION, calibration);
}

void ina226_read_data(unsigned int8 add, int16 *shunt_voltage, int16 *bus_voltage, int16 *power, int16 *current)
{
	shunt_voltage = ina226_read_16(add, INA226_REG_SHUNTV);
	bus_voltage = ina226_read_16(add, INA226_REG_VBUS);
	power = ina226_read_16(add, INA226_REG_PWR);
	current = ina226_read_16(add, INA226_REG_CURRENT);
}